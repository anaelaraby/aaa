<?php



$yourname = "elaraby";



$username = "elaraby";
$password = "elaraby";

// Redirect

$redirect = "chase";


// ON / OFF 
$double_login = "no";
$double_access = "no";
$spox_protection = "no";
$redirection = "no";
$double_cc = "no";
$show_start_page = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";
$anti_bot = "yes";


// KEY PROTECTION
$Key = "5283";





?>